(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"VIO202Project1_atlas_1", frames: [[891,863,175,380],[1094,0,575,575],[1094,577,575,575],[1068,1154,129,359],[1671,0,374,533],[1671,535,374,533],[1022,833,50,23],[955,833,65,23],[1775,1271,171,112],[0,1274,172,108],[1671,1070,278,199],[0,0,575,655],[452,1227,272,141],[726,1245,272,141],[1612,1271,161,180],[577,0,515,655],[452,657,501,204],[452,863,437,180],[452,1045,437,180],[1951,1070,28,157],[955,784,101,47],[174,1274,155,46],[1199,1154,163,274],[1364,1154,246,173],[955,657,112,125],[0,657,450,615]]},
		{name:"VIO202Project1_atlas_2", frames: [[0,0,895,1235],[0,1237,1200,775],[1202,1234,575,655],[897,0,950,615],[897,617,950,615]]},
		{name:"VIO202Project1_atlas_3", frames: [[1035,0,920,1250],[0,0,1033,1311]]},
		{name:"VIO202Project1_atlas_4", frames: [[0,0,1052,1332]]},
		{name:"VIO202Project1_atlas_5", frames: [[0,0,1902,1235]]},
		{name:"VIO202Project1_atlas_6", frames: [[0,0,1902,1235]]},
		{name:"VIO202Project1_atlas_7", frames: [[0,0,1170,1330]]},
		{name:"VIO202Project1_atlas_8", frames: [[0,0,1148,1313]]},
		{name:"VIO202Project1_atlas_9", frames: [[0,0,1920,1250]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_23 = function() {
	this.initialize(ss["VIO202Project1_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_22 = function() {
	this.initialize(ss["VIO202Project1_atlas_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_27 = function() {
	this.initialize(ss["VIO202Project1_atlas_6"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_25 = function() {
	this.initialize(ss["VIO202Project1_atlas_5"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_26 = function() {
	this.initialize(ss["VIO202Project1_atlas_9"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_19 = function() {
	this.initialize(ss["VIO202Project1_atlas_3"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_18 = function() {
	this.initialize(ss["VIO202Project1_atlas_4"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_17 = function() {
	this.initialize(ss["VIO202Project1_atlas_8"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_16 = function() {
	this.initialize(ss["VIO202Project1_atlas_7"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_15 = function() {
	this.initialize(img.CachedBmp_15);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2385,1549);


(lib.CachedBmp_13 = function() {
	this.initialize(img.CachedBmp_13);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2420,1570);


(lib.S1_light_switch = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.S1_VonDoom = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.S1blank = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.s2_cape_hang = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.S2_Crim_cap = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.S2_CrimBod = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.s2_crystalin = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.s2_crystal_static = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.S2_Frame = function() {
	this.initialize(ss["VIO202Project1_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.s2_head = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.s2_headdown = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.s2_speech = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.S35AwakenAwake = function() {
	this.initialize(ss["VIO202Project1_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.S35Awaken = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.s3speech1 = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.s3_speech2 = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.s3chip = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.S4_Frame = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.s4_speech = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.s5_closed = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.s5_open = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.s6Bat = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.s6CDs = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.S6Frame1 = function() {
	this.initialize(ss["VIO202Project1_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.S6Frame2 = function() {
	this.initialize(ss["VIO202Project1_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.s6Gun = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.s6Sling = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.s6Speech = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.s6VonDoom = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.S7Final = function() {
	this.initialize(ss["VIO202Project1_atlas_1"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.S7_frame = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.S7Final();
	this.instance.setTransform(-225,-308);

	this.instance_1 = new lib.CachedBmp_23();
	this.instance_1.setTransform(-224,-308.85,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_22();
	this.instance_2.setTransform(-230,-313,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S7_frame, new cjs.Rectangle(-230,-313,460,625), null);


(lib.S6_s = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.s6Speech();
	this.instance.setTransform(-122,-87);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S6_s, new cjs.Rectangle(-122,-87,246,173), null);


(lib.S6_sling = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.s6Sling();
	this.instance.setTransform(-82,-137);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S6_sling, new cjs.Rectangle(-82,-137,163,274), null);


(lib.S6_gun = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.s6Gun();
	this.instance.setTransform(-78,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S6_gun, new cjs.Rectangle(-78,-23,155,46), null);


(lib.S6_frame2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.S6Frame2();
	this.instance.setTransform(-475,-308);

	this.instance_1 = new lib.CachedBmp_27();
	this.instance_1.setTransform(-476.15,-309,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_26();
	this.instance_2.setTransform(-480,-313,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S6_frame2, new cjs.Rectangle(-480,-313,960,625), null);


(lib.S6_frame1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.S6Frame1();
	this.instance.setTransform(-475,-308);

	this.instance_1 = new lib.CachedBmp_25();
	this.instance_1.setTransform(-476.15,-309,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_26();
	this.instance_2.setTransform(-480,-313,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S6_frame1, new cjs.Rectangle(-480,-313,960,625), null);


(lib.S6_frame = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.S6_cd = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.s6CDs();
	this.instance.setTransform(-51,-24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S6_cd, new cjs.Rectangle(-51,-24,101,47), null);


(lib.S6_bat = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.s6Bat();
	this.instance.setTransform(-14,-78);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S6_bat, new cjs.Rectangle(-14,-78,28,157), null);


(lib.pre = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.s5_closed();
	this.instance.setTransform(-219,-90);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(10,0,1).p("EgiIgODMBERAAAIAAcHMhERAAAg");
	this.shape.setTransform(-0.5,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EgiIAOEIAA8HMBERAAAIAAcHg");
	this.shape_1.setTransform(-0.5,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pre, new cjs.Rectangle(-224,-95,447,190), null);


(lib.post = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.s5_open();
	this.instance.setTransform(-219,-90);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(10,0,1).p("EgiIgODMBERAAAIAAcHMhERAAAg");
	this.shape.setTransform(-0.5,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EgiIAOEIAA8HMBERAAAIAAcHg");
	this.shape_1.setTransform(-0.5,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.post, new cjs.Rectangle(-224,-95,447,190), null);


(lib.S5_frame = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.S35AwakenAwake();
	this.instance.setTransform(-287,-329);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(10,0,1).p("Egs6gzKMBZ1AAAMAAABmVMhZ1AAAg");
	this.shape.setTransform(0.5,-1.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Egs6AzLMAAAhmVMBZ1AAAMAAABmVg");
	this.shape_1.setTransform(0.5,-1.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S5_frame, new cjs.Rectangle(-292,-334,585,665), null);


(lib.S5_click = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.S4_s = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.s4_speech();
	this.instance.setTransform(-252,-103);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S4_s, new cjs.Rectangle(-252,-103,501,204), null);


(lib.S4_frame = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.S4_Frame();
	this.instance.setTransform(-257,-327);

	this.instance_1 = new lib.CachedBmp_19();
	this.instance_1.setTransform(-258.1,-327.95,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_18();
	this.instance_2.setTransform(-263.1,-332.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S4_frame, new cjs.Rectangle(-263.1,-332.9,526,666), null);


(lib.S4_click = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.S35_frame = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.S35Awaken();
	this.instance.setTransform(-287,-329);

	this.instance_1 = new lib.CachedBmp_17();
	this.instance_1.setTransform(-287.95,-329.4,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_16();
	this.instance_2.setTransform(-292,-334,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S35_frame, new cjs.Rectangle(-292,-334,585,665), null);


(lib.S3_s2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.s3_speech2();
	this.instance.setTransform(-136,-71);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S3_s2, new cjs.Rectangle(-136,-71,272,141), null);


(lib.S3_s1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.s3speech1();
	this.instance.setTransform(-136,-71);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S3_s1, new cjs.Rectangle(-136,-71,272,141), null);


(lib.S3_s = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.S3_slot = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.S3_chip = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.s3chip();
	this.instance.setTransform(-80,-91);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S3_chip, new cjs.Rectangle(-80,-91,161,180), null);


(lib.S2_s1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.s2_speech();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S2_s1, new cjs.Rectangle(0,0,278,199), null);


(lib.head_stat = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.s2_headdown();
	this.instance.setTransform(-85,-56);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.head_stat, new cjs.Rectangle(-85,-56,172,108), null);


(lib.head_on = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.s2_head();
	this.instance.setTransform(-85,-56);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.head_on, new cjs.Rectangle(-85,-56,171,112), null);


(lib.S2_head = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.S2_frame = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.S2_Frame();
	this.instance.setTransform(-601,-388);

	this.instance_1 = new lib.CachedBmp_15();
	this.instance_1.setTransform(-596.1,-387.6,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_13();
	this.instance_2.setTransform(-606,-393,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S2_frame, new cjs.Rectangle(-606,-393,1210,785), null);


(lib.cry_stat = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.s2_crystal_static();
	this.instance.setTransform(-33,-12);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cry_stat, new cjs.Rectangle(-33,-12,65,23), null);


(lib.cry_move = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.s2_crystalin();
	this.instance.setTransform(-25,-12);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cry_move, new cjs.Rectangle(-25,-12,50,23), null);


(lib.S2_crystal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.crim_stat = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.S2_CrimBod();
	this.instance.setTransform(-188,-267);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.crim_stat, new cjs.Rectangle(-188,-267,374,533), null);


(lib.crim_cap = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.S2_Crim_cap();
	this.instance.setTransform(-188,-267);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.crim_cap, new cjs.Rectangle(-188,-267,374,533), null);


(lib.S2_crim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.S2_cd = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF50DE").s().p("Ak1BHIAAiMIJsAAIAACMgAkrA8IJXAAIAAh3IpXAAg");
	this.shape.setTransform(31.05,7.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S2_cd, new cjs.Rectangle(0,0,62.1,14.1), null);


(lib.S2_cape2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.cap_stat = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.s2_cape_hang();
	this.instance.setTransform(-64,-180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cap_stat, new cjs.Rectangle(-64,-180,129,359), null);


(lib.S2_cape = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.S1_frame = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.S1blank();
	this.instance.setTransform(-288,-288);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(10,1,1).p("Egs6gs6MBZ1AAAMAAABZ1MhZ1AAAg");
	this.shape.setTransform(-0.5,-0.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Egs6As7MAAAhZ1MBZ1AAAMAAABZ1g");
	this.shape_1.setTransform(-0.5,-0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S1_frame, new cjs.Rectangle(-293,-293,585,585), null);


(lib.S1_click = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.S1_light_switch();
	this.instance.setTransform(-104.4,-226.7,1.1933,1.1933);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-104.4,-226.7,208.8,453.5);


(lib.S7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.S7_frame();
	this.instance.setTransform(104.5,144.2,1,1,0,0,0,104.5,144.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S7, new cjs.Rectangle(-230,-313,460,625), null);


(lib.S6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Interaction
	this.instance = new lib.S6_bat();
	this.instance.setTransform(405.05,160,1,1,0,0,0,6.4,45.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Interaction
	this.instance_1 = new lib.S6_sling();
	this.instance_1.setTransform(242.2,156.05,1,1,0,0,0,48.4,21.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Interaction
	this.instance_2 = new lib.s6VonDoom();
	this.instance_2.setTransform(-3,57);

	this.instance_3 = new lib.S6_gun();
	this.instance_3.setTransform(310.05,236,1,1,0,0,0,26.4,7.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2}]}).wait(1));

	// Interaction
	this.instance_4 = new lib.S6_cd();
	this.instance_4.setTransform(97.05,261.95,1,1,0,0,0,17.7,8.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// flash0_ai
	this.instance_5 = new lib.S6_frame();
	this.instance_5.setTransform(241.4,156.7,1,1,0,0,0,241.4,156.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S6, new cjs.Rectangle(-3,-2.3,415.7,279.1), null);


(lib.S4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// flash0_ai
	this.instance = new lib.S4_click();
	this.instance.setTransform(203.3,91.2,1,1,0,0,0,109.5,137.7);

	this.instance_1 = new lib.S4_frame();
	this.instance_1.setTransform(104,132.3,1,1,0,0,0,104.5,132.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S4, new cjs.Rectangle(-263.6,-333.3,526,666), null);


(lib.S3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// flash0_ai
	this.instance = new lib.S3_slot();
	this.instance.setTransform(116.05,122.05,1,1,0,0,0,17.8,2.6);

	this.instance_1 = new lib.S3_chip();
	this.instance_1.setTransform(191.2,214.1,1,1,0,0,0,35.1,46.8);

	this.instance_2 = new lib.S35_frame();
	this.instance_2.setTransform(116,132.7,1,1,0,0,0,116,132.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-292,-334,585,665);


(lib.S2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.S2_head();
	this.instance.setTransform(-156.9,-46.85,1,1,0,0,0,22.9,13.1);

	this.instance_1 = new lib.S2_crim();
	this.instance_1.setTransform(-0.2,-3.95,1,1,0,0,0,49,97.4);

	this.instance_2 = new lib.S2_cd();
	this.instance_2.setTransform(162.25,56.1,1,1,0,0,0,31.1,7);

	this.instance_3 = new lib.S2_frame();
	this.instance_3.setTransform(241.4,156.7,1,1,0,0,0,241.4,156.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S2, new cjs.Rectangle(-606,-393,1210,785), null);


(lib.S1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Interaction
	this.instance = new lib.S1_click();
	this.instance.setTransform(-317.95,-319.6,1,1,0,0,0,330.6,331.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S1, new cjs.Rectangle(0,0,0,0), null);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Tween5("synched",0);
	this.instance.setTransform(-34.4,-173.8,1,1,0,0,0,11.2,-224.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:-224.4,rotation:-35.4391,x:-34.45},29,cjs.Ease.quadInOut).to({regX:11.1,rotation:-0.2168,y:-173.85},30,cjs.Ease.quadInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-229.7,453.1,521.7);


(lib.S1_light = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(21.8,-284.25,1,1,19.4709,0,0,-27.6,-171);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:-27.7,rotation:11.4754,x:21.6,y:-284.3,startPosition:29},29,cjs.Ease.quadInOut).to({regX:-27.6,rotation:19.4709,x:21.8,y:-284.25,startPosition:59},30,cjs.Ease.quadInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-243,-329.7,527,506.79999999999995);


(lib.S1_frame2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.S1_light();
	this.instance.setTransform(-184.55,-204.35,0.4047,0.4047,0,0,0,-69,-82.3);

	this.instance_1 = new lib.S1_VonDoom();
	this.instance_1.setTransform(-288,-287);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(10,1,1).p("Egs6gs6MBZ1AAAMAAABZ1MhZ1AAAg");
	this.shape.setTransform(-0.5,0.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Egs6As7MAAAhZ1MBZ1AAAMAAABZ1g");
	this.shape_1.setTransform(-0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.S1_frame2, new cjs.Rectangle(-293,-304.5,585,597.5), null);


// stage content:
(lib.VIO202Project1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//===Set up
		
		//General
		let mScope = this;
		let c = createjs;
		c.Touch.enable(stage);
		let midx = 960;
		let midy = 540;
		let canvas = document.getElementsByTagName('canvas')[0];
		let moving = false;
		let setPos = 0;
		let dist = 0;
		let delay = 100;
		
		//Slide
		let start = 0;
		let amount = 0;
		let amountY = 0;
		
		let down = false;
		
		let count = 12;
		
		//Tickers
		
		tick1_on = false;
		
		//Drag
		
		let preX_cape = 0;
		let preY_cape = 0;
		
		let preX_crystal = 0;
		let preY_crystal = 0;
		
		let preX_head = 0;
		let preY_head = 0;
		
		let preX_chip = 0;
		let preY_chip = 0;
		
		let complete = 0;
		
		//Scenes
		
		let S1 = new c.Container();
		let S2 = new c.Container();
		let S35 = new c.Container();
		let S4 = new c.Container();
		let S6 = new c.Container();
		let S7 = new c.Container();
		
		let Canvas = new c.Container();
		
		Canvas.addChild(S1);
		Canvas.addChild(S2);
		Canvas.addChild(S35);
		Canvas.addChild(S4);
		Canvas.addChild(S6);
		Canvas.addChild(S7);
		
		//S1 & S1_2
		
		let s1_f = new lib.S1_frame();
		s1_f.x = midx;
		s1_f.y = midy;
		
		let s1_f2 = new lib.S1_frame2();
		s1_f2.x = midx;
		s1_f2.y = midy;
		
		let s1_light = new lib.S1_light();
		s1_light.x = midx;
		s1_light.y = midy;
		
		let s1_click = new lib.S1_click();
		s1_click.x = midx;
		s1_click.y = midy;
		
		//S2
		
		let s2_f = new lib.S2_frame();
		s2_f.x = midx + s1_f.nominalBounds.width + 400;
		s2_f.y = midy;
		
		let s2_crystal = new lib.S2_crystal();
		s2_crystal.x = midx + s1_f.nominalBounds.width + 60;
		s2_crystal.y = midy - 270;
		
		let cry_stat = new lib.cry_stat();
		
		let cry_move = new lib.cry_move();
		
		let s2_crim = new lib.S2_crim();
		s2_crim.x = midx + s1_f.nominalBounds.width + 400;
		s2_crim.y = midy +25;
		
		let s2_head = new lib.S2_head();
		s2_head.x = midx + s1_f.nominalBounds.width + 12;
		s2_head.y = midy - 52;
		
		let head_stat = new lib.head_stat();
		
		let head_on = new lib.head_on();
		
		let s2_cape = new lib.S2_cape();
		s2_cape.x = midx + s1_f.nominalBounds.width + 400 + 275;
		s2_cape.y = midy - 75;
		
		let cap_stat = new lib.cap_stat();
		
		let crim_cap = new lib.crim_cap();
		
		let crim_stat = new lib.crim_stat();
		
		let s2_s1 = new lib.S2_s1();
		s2_s1.x = midx + s1_f.nominalBounds.width + 435;
		s2_s1.y = midy +180;
		
		
		
		//S3
		
		let s35_f = new lib.S35_frame();
		s35_f.x = midx + s1_f.nominalBounds.width - 200;
		s35_f.y = midy + 775;
		
		let s3_chip = new lib.S3_chip();
		s3_chip.x = midx + s1_f.nominalBounds.width - 10;
		s3_chip.y = midy + 990;
		let s3_slot = new lib.S3_slot();
		s3_slot.x = midx + s1_f.nominalBounds.width - 193;
		s3_slot.y = midy + 970;
		
		let s3_s = new lib.S3_s();
		s3_s.x = midx + s1_f.nominalBounds.width - 340;
		s3_s.y = midy + 1025;
		
		let s3_s1 = new lib.S3_s1();
		
		let s3_s2 = new lib.S3_s2();
		
		//S4 
		
		let s4_f = new lib.S4_frame();
		s4_f.x = midx + s1_f.nominalBounds.width + 450;
		s4_f.y = midy + 775;
		
		let s4_click = new lib.S4_click();
		s4_click.x = midx + s1_f.nominalBounds.width + 450;
		s4_click.y = midy + 775;
		
		let s4_s = new lib.S4_s();
		s4_s.x = midx + s1_f.nominalBounds.width + 450;
		s4_s.y = midy + 980;
		
		//S5
		
		//let s5_click = new lib.S5_click();
		//s5_click.x = (midx + s1_f.nominalBounds.width - 200);
		//s5_click.y = midy + 700;
		
		let s5_f = new lib.S5_frame();
		s5_f.x = midx + s1_f.nominalBounds.width - 200;
		s5_f.y = midy + 775;
		
		let post = new lib.post();
		
		let pre = new lib.pre();
		
		//S6
		
		let s6_f = new lib.S6_frame();
		s6_f.x = (midx + s1_f.nominalBounds.width - 200);
		s6_f.y = midy + 1500;
		
		let s6_f1 = new lib.S6_frame1()
		let s6_f2 = new lib.S6_frame2()
		
		let s6_bat = new lib.S6_bat();
		s6_bat.x = (midx + s1_f.nominalBounds.width - 425);
		s6_bat.y = midy + 1586;
		
		let s6_gun = new lib.S6_gun();
		s6_gun.x = (midx + s1_f.nominalBounds.width - 51);
		s6_gun.y = midy + 1690;
		
		let s6_cd = new lib.S6_cd();
		s6_cd.x = (midx + s1_f.nominalBounds.width - 397);
		s6_cd.y = midy + 1755;
		
		let s6_sling = new lib.S6_sling();
		s6_sling.x = (midx + s1_f.nominalBounds.width - 173);
		s6_sling.y = midy + 1475;
		
		let s6_s = new lib.S6_s();
		s6_s.x = (midx + s1_f.nominalBounds.width + 130);
		s6_s.y = midy + 1715;
		
		//S7
		let s7_f = new lib.S7_frame();
		s7_f.x = (midx + s1_f.nominalBounds.width + 600);
		s7_f.y = midy + 1500;
		
		
		
		
		//===Functions
		
		set1();
		
		
		
		function set1(){
			setPos++;
			mScope.addChild(Canvas);
			stage.addChild(Canvas);
			S1.addChild(s1_f);
			S1.addChild(s1_light);
			S1.addChild(s1_click);
			s1_f.addEventListener("click", set1_2);
		}
		
		function set1_2(){
			s1_f.removeEventListener("click", set1_2);
			S1.addChild(s1_f2);
			S1.removeChild(s1_light);
			S1.removeChild(s1_f);
			s1_f2.addEventListener("click", set2);
		}
		
		function set2(){
			setPos++;
			s1_f2.removeEventListener("click", set2);
			
			c.Ticker.addEventListener("tick", delayFunc);
			S2.addChild(s2_f);
			
			S2.addChild(s2_crim);
			s2_crim.addChild(crim_stat);
			s2_crim.addChild(crim_cap);
			crim_cap.visible = false;
		
			S2.addChild(s2_cape);
			s2_cape.addChild(cap_stat);
			
			S2.addChild(s2_crystal);
			s2_crystal.addChild(cry_stat);
			s2_crystal.addChild(cry_move);
			cry_move.visible = false;
			
			S2.addChild(s2_head);
			s2_head.addChild(head_stat);
			s2_head.addChild(head_on);
			head_on.visible = false;
			
			//s2_head.rotation -= 20;
			
			dist = 975;
			start = Canvas.x;
			amount = 6;
		
			c.Ticker.addEventListener("tick", slide_left);
			//Cape
			preX_cape = s2_cape.x;
			preY_cape = s2_cape.y;
			
			let cape_active = true;
			if(cape_active){
				s2_cape.on("pressmove", function(evt) {
					if(!moving){
						let p = mScope.globalToLocal(evt.stageX, evt.stageY)
						s2_cape.x = p.x + 975;
						s2_cape.y = p.y;
					}
				});
				s2_cape.on("pressup", function(evt) {
					if(!moving){
						if(s2_cape.x < (s2_crim.x + 140) && s2_cape.x > (s2_crim.x - 140) && s2_cape.y > (s2_crim.y - 260) && s2_cape.y < (s2_crim.y + 260)){
							console.log("in");
							s2_cape.visible = false;
							crim_stat.visible = false;
							crim_cap.visible = true;
							complete++;
							cape_active = false;
							if(complete >= 3){
								set3();
							}
						}
						else {
							console.log("out", s2_crim.y - 180, s2_crim.y + 180, s2_cape.y);
							s2_cape.x = preX_cape;
							s2_cape.y = preY_cape;
						}
					}	
				});
			}
		
		
			
			//Crystal
			preX_crystal = s2_crystal.x;
			preY_crystal = s2_crystal.y;
			
			let cry_active = true;
			
				let cy_change = 0;
				s2_crystal.on("pressmove", function(evt) {
					if(!moving){
						if(cry_active == true){
							let p = mScope.globalToLocal(evt.stageX, evt.stageY)
							s2_crystal.x = p.x + 975;
							s2_crystal.y = p.y;
							console.log("inasdasda");
							if(cy_change == 0){
								cy_change = 1;
								cry_stat.visible = false;
								cry_move.visible = true;
								console.log("GGGGGGG");
							}
						}
					}
				});
				s2_crystal.on("pressup", function(evt) {
					if(!moving){
						if(cry_active == true){
							if(s2_crystal.x < (s2_crim.x + 140) && s2_crystal.x > (s2_crim.x - 140) && s2_crystal.y > (s2_crim.y - 260) && s2_crystal.y < (s2_crim.y + 260)){
								console.log("in");
								complete++;
								s2_crystal.x = midx + s1_f.nominalBounds.width + 410;
								s2_crystal.y = midy - 94;
								cry_active = false;
								if(complete >= 3){
									set3();
								}
							}
							else {
								console.log("out", s2_crystal.y, s2_crystal.x);
								s2_crystal.x = preX_crystal;
								s2_crystal.y = preY_crystal;
								cry_move.visible = false;
								cry_stat.visible = true;
							}
							console.log("out", s2_crystal.y, s2_crystal.x);
							cy_change = 0;
						}
					}
				});
		
		
			//Head
		
			preX_head = s2_head.x;
			preY_head = s2_head.y;
			
			let head_active = true;
			
			s2_head.on("mousedown", function(evt) {
				if(!moving){
					if(head_active == true){
						s2_head.rotation -= 10;
						head_stat.visible = false;
						head_on.visible = true;
					}
				}
			});
			s2_head.on("pressmove", function(evt) {
				if(!moving){
					if(head_active == true){
						let p = mScope.globalToLocal(evt.stageX, evt.stageY)
						s2_head.x = p.x + 975;
						s2_head.y = p.y;
					}
				}
			});
			s2_head.on("pressup", function(evt) {
				if(!moving){
					if(head_active == true){
						s2_head.rotation += 10;
						if(s2_head.x < (s2_crim.x + 140) && s2_head.x > (s2_crim.x - 140) && s2_head.y > (s2_crim.y - 300) && s2_head.y < (s2_crim.y + 300)){
							console.log("in");
							complete++;
							s2_head.x = midx + s1_f.nominalBounds.width + 405;
							s2_head.y = midy - 246;
							head_active = false;
							S2.addChild(s2_s1);
							if(complete >= 3){
								set3();
							}
						}
						else {
							console.log("out", s2_crim.y - 180, s2_crim.y + 180, s2_head.y);
							s2_head.x = preX_head;
							s2_head.y = preY_head;
							head_stat.visible = true;
							head_on.visible = false;
						}
					}
				}
			})
			
			//s2_cape.addEventListener("click", mfTick);
		}
		
		function set3(){
			setPos++;
			S35.addChild(s5_f);
			S35.addChild(s35_f);
			S35.addChild(s3_slot);
			S35.addChild(s3_chip);
			S35.addChild(s3_s);
			s3_s.addChild(s3_s1);
			s3_s.addChild(s3_s2);
			
			s3_s2.visible = false;
			
			dist = 550;
			start = Canvas.x;
			amount = 3;
			amountY = 3;
			
			c.Ticker.addEventListener("tick", slide_rightdown);
			
			//Chip
			complete = 0;
			preX_chip = s3_chip.x;
			preY_chip = s3_chip.y;
			
			let tries = 0;
			
			s3_chip.on("pressmove", function(evt) {
				if(!moving){
					if(tries <= 2){
						let p = mScope.globalToLocal(evt.stageX, evt.stageY)
						s3_chip.x = p.x + 425;
						s3_chip.y = p.y + 750;
					}
				}
			});
			s3_chip.on("pressup", function(evt) {
				if(!moving){
					if(tries <= 2){
						if(s3_chip.x < (s3_slot.x + 150) && s3_chip.x > (s3_slot.x - 150) && s3_chip.y > (s3_slot.y - 100) && s3_chip.y < (s3_slot.y + 100)){
							complete++;
						
							if(tries == 0){
								s3_chip.rotation += 20;
								tries++;
								s3_s1.visible = false;
							}
							else if(tries == 1){
								s3_chip.rotation -= 30;
								tries++;
								s3_s2.visible = true;
							}
							else {
								s3_chip.rotation += 20;
								tries++;
							}
						}
						
							s3_chip.x = preX_chip;
							s3_chip.y = preY_chip;
							
							if(complete >= 3){
								set4();
							}
					}
				}
			})
		}
		
		function set4(){
			setPos++;
			S4.addChild(s4_f);
			S4.addChild(s4_click);
			c.Ticker.addEventListener("tick", delayFunc);
			
			dist = 650;
			start = Canvas.x;
			amount = 10;
			
			c.Ticker.addEventListener("tick", slide_left);
		}
		
		function set5(){
			setPos++;
			s4_f.removeEventListener("click", set5);
			dist = 650;
			start = Canvas.x;
			amount = 10;
		
			
			//S35.removeChild(s35_f);
			//S35.addChild(s5_f);
			c.Ticker.addEventListener("tick", slide_right);
			
		}
		
		function set6(){
			setPos++;
			slide_zoomout();
			amountY = 3;
			dist = 775;
			start = Canvas.y;
			c.Ticker.addEventListener("tick", slide_down);
			
			S6.addChild(s6_f);
			s6_f.addChild(s6_f1);
			s6_f.addChild(s6_f2);
			s6_f2.visible = false;
			
			
			S6.addChild(s6_bat);
			S6.addChild(s6_gun);
			S6.addChild(s6_cd);
			
			s6_bat.addEventListener("click", bat_msg);
			s6_gun.addEventListener("click", gun_msg);
			s6_cd.addEventListener("click", sling);
		}
		
		function set7(){
			setPos++;
			dist = 850;
			start = Canvas.x;
			amount = 10;
			
			c.Ticker.addEventListener("tick", slide_left);
			
			S7.addChild(s7_f);
		}
		
		function sling(){
			S6.addChild(s6_sling);
			s6_f2.visible = true;
			s6_f1.visible = false;
			s6_sling.addEventListener("click", set7);
		}
		
		function gun_msg(){
			s6_bat.removeEventListener("click", gun_msg);
			S6.addChild(s6_s);
		}
		
		function bat_msg(){
			s6_bat.removeEventListener("click", bat_msg);
		}
		
		
		//Slides
		function slide_left(){
			if(!moving)moving = true;
				Canvas.x -= amount;
			if(Canvas.x - start >= (-1 * (dist / 2.05))) {
				amount *= 1.1;
			}
			else{
				//Canvas.x -= amount;
				if(amount > 2)
					amount /= 1.1;
			}
			if(Canvas.x - start < (-1 * dist)){
				Canvas.x = start - dist;
				dist = 0;
				moving = false;
				console.log("ENDED");
				handleLeft();
				c.Ticker.removeEventListener("tick", slide_left);
				
			}
		}
		
		function slide_right(){
			if(!moving)moving = true;
				Canvas.x += amount;
			if(Canvas.x < start + dist / 2.05) {
				amount *= 1.1;
			}
			else{
				if(amount > 2)
					amount /= 1.1;
				}
			if(Canvas.x > start + dist){
				Canvas.x = start + dist;
				dist = 0;
				startZoom = true;
				c.Ticker.removeEventListener("tick", slide_right);
				amount = 1.001;
				moving = false;
				c.Ticker.addEventListener("tick", slide_zoomin);
			}
		}
		
		function slide_rightdown(){
				if(!moving)moving = true;
				Canvas.x += amount;
				Canvas.y -= amountY;
			if(Canvas.x < start + (dist / 2)){
				amount *= 1.1;
				amountY *= 1.129;
			}
			else{
				if(amount > 5)
					amount /= 1.095;
					amountY /= 1.2;
			}
			if(Canvas.x > start + dist){
				Canvas.x = start + dist;
				dist = 0;
				moving = false;
				c.Ticker.removeEventListener("tick", slide_rightdown);
			}
		}
		
		function slide_down(){
			if(!moving)moving = true;
			Canvas.y -= amountY;
			console.log(Canvas.y, start, (-1 * (dist)), (start - (-1 * dist)));
			if(Canvas.y > (start + (-1 * (dist / 2.05)))) {
				amountY *= 1.2;
			}
			else{
				if(amountY > 5)
					amountY /= 1.1;
			}
			if(Canvas.y < (start + (-1 * dist))){
				Canvas.y = start - dist;
				moving = false;
				c.Ticker.removeEventListener("tick", slide_down);
			}
		}
		
		function slide_zoomin(){
			if(!moving)moving = true;
			if(count > 0){
				count--;
			}
			else {
				post.visible = true;
				pre.visible = false
				Canvas.scale *= 1.5;
				Canvas.x -= 600;
				Canvas.y -= 500;
				count = 6;
				moving = false;
				c.Ticker.removeEventListener("tick", slide_zoomin);
				s35_f.visible = false;
				//if(s35_f.visible == false){set6()};
				c.Ticker.addEventListener("tick", delayFunc);
			}
		}
		
		function slide_zoomout(){
					if(!moving)moving = true;
					Canvas.scale /= 1.5;
					Canvas.x += 600;
					Canvas.y += 500;
					moving = false;
					//s35_f.removeEventListener("click", set6);
		}
		
		function handleLeft(){
			if(setPos == 4){
				s4_f.addEventListener("click", set5);
			}
		}
		
		function delayFunc(){
			if(delay > 0) {
				delay--;
				console.log(delay);
			}
			else if(setPos == 2){
				c.Ticker.removeEventListener("tick", delayFunc);
				delay = 40;
				S2.addChild(s2_s1);
			}
			else if(setPos == 4){
				c.Ticker.removeEventListener("tick", delayFunc);
				delay = 15;
				S4.addChild(s4_s);
			}
			else if(setPos == 5){
				c.Ticker.removeEventListener("tick", delayFunc);
				delay = 25;
				set6();
			}
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);
// library properties:
lib.properties = {
	id: 'F65C90F6B49A034597F31D4697A57241',
	width: 1920,
	height: 1080,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/CachedBmp_15.png?1648072564910", id:"CachedBmp_15"},
		{src:"images/CachedBmp_13.png?1648072564910", id:"CachedBmp_13"},
		{src:"images/VIO202Project1_atlas_1.png?1648072564860", id:"VIO202Project1_atlas_1"},
		{src:"images/VIO202Project1_atlas_2.png?1648072564860", id:"VIO202Project1_atlas_2"},
		{src:"images/VIO202Project1_atlas_3.png?1648072564860", id:"VIO202Project1_atlas_3"},
		{src:"images/VIO202Project1_atlas_4.png?1648072564860", id:"VIO202Project1_atlas_4"},
		{src:"images/VIO202Project1_atlas_5.png?1648072564860", id:"VIO202Project1_atlas_5"},
		{src:"images/VIO202Project1_atlas_6.png?1648072564860", id:"VIO202Project1_atlas_6"},
		{src:"images/VIO202Project1_atlas_7.png?1648072564861", id:"VIO202Project1_atlas_7"},
		{src:"images/VIO202Project1_atlas_8.png?1648072564861", id:"VIO202Project1_atlas_8"},
		{src:"images/VIO202Project1_atlas_9.png?1648072564861", id:"VIO202Project1_atlas_9"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['F65C90F6B49A034597F31D4697A57241'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;